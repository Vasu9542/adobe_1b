import pdfplumber

def extract_title(pdf):
    if pdf.metadata:
        title_meta = pdf.metadata.get("Title", "").strip()
        if title_meta and "untitled" not in title_meta.lower():
            return title_meta

    first_page = pdf.pages[0]
    words = first_page.extract_words(extra_attrs=["size"])

    if not words:
        return "Untitled Document"

    sorted_words = sorted(words, key=lambda x: -x["size"])
    title_lines = []
    used_y_coords = set()
    for word in sorted_words:
        y = round(word["top"])
        if y not in used_y_coords and len(title_lines) < 2:
            title_lines.append(word["text"].strip())
            used_y_coords.add(y)

    if title_lines:
        return " ".join(title_lines)

    return "Untitled Document"

if __name__ == "__main__":
    pdf_path = "sample_dataset/pdfs/example.pdf"
    with pdfplumber.open(pdf_path) as pdf:
        title = extract_title(pdf)
        print(f"📘 Extracted Title: {title}")
