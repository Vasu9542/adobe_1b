from pathlib import Path
import json
import pdfplumber

def classify_heading(size, thresholds):
    if size >= thresholds.get('H1', 20): return 'H1'
    if size >= thresholds.get('H2', 16): return 'H2'
    if size >= thresholds.get('H3', 13): return 'H3'
    return None

def get_font_thresholds(pages):
    sizes = []
    for page in pages:
        for char in page.chars:
            sizes.append(round(char["size"]))
    sizes = sorted(set(sizes), reverse=True)
    return {
        "H1": sizes[0] if len(sizes) > 0 else 20,
        "H2": sizes[1] if len(sizes) > 1 else 16,
        "H3": sizes[2] if len(sizes) > 2 else 13
    }

def extract_outline(pdf):
    outline = []
    font_thresholds = get_font_thresholds(pdf.pages)

    for page_num, page in enumerate(pdf.pages):
        lines = page.extract_words(use_text_flow=True, keep_blank_chars=False)
        for line in lines:
            size = round(line["size"])
            level = classify_heading(size, font_thresholds)
            if level:
                outline.append({
                    "level": level,
                    "text": line["text"].strip(),
                    "page": page_num
                })
    return outline

def extract_title(pdf):
    if pdf.metadata:
        title_meta = pdf.metadata.get("Title", "").strip()
        if title_meta and "untitled" not in title_meta.lower():
            return title_meta

    first_page = pdf.pages[0]
    words = first_page.extract_words(extra_attrs=["size"])

    if not words:
        return "Untitled Document"

    sorted_words = sorted(words, key=lambda x: -x["size"])
    title_lines = []
    used_y_coords = set()
    for word in sorted_words:
        y = round(word["top"])
        if y not in used_y_coords and len(title_lines) < 2:
            title_lines.append(word["text"].strip())
            used_y_coords.add(y)

    if title_lines:
        return " ".join(title_lines)

    return "Untitled Document"

def process_pdfs():
    input_dir = Path("/app/input")
    output_dir = Path("/app/output")
    output_dir.mkdir(parents=True, exist_ok=True)

    for pdf_file in input_dir.glob("*.pdf"):
        with pdfplumber.open(pdf_file) as pdf:
            title = extract_title(pdf)
            outline = extract_outline(pdf)

        result = {
            "title": title,
            "outline": outline
        }

        output_path = output_dir / f"{pdf_file.stem}.json"
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

if __name__ == "__main__":
    process_pdfs()